package com.example.customer_service.service;

import java.util.List;

import com.example.customer_service.entity.Customer;

public interface CustomerService {
	
    List<Customer> getAllCustomers();
    Customer getCustomerById(String id);
    Customer createCustomer(Customer customer);
    Customer updateCustomer(String id, Customer updatedCustomer);
    boolean deleteCustomer(String id);


}
