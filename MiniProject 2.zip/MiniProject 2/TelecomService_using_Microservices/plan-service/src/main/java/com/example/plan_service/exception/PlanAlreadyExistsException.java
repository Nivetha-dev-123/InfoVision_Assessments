package com.example.plan_service.exception;

public class PlanAlreadyExistsException  extends RuntimeException{

	public PlanAlreadyExistsException(String message) {
		super(message);
	}
	
	

}
