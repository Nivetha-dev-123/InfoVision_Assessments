package com.infovision.RechargeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RechargeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
